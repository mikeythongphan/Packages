﻿namespace OneWitsCore.Helpers
{
    public static class GenericHelper
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="length"></param>
        /// <returns></returns>
        public static string GenerateVerificationCode(int length)
        {
            var chArray = "0123456789".ToCharArray();
            var str = string.Empty;
            var random = new Random();
            for (int i = 0; i < length; i++)
            {
                int index = random.Next(1, chArray.Length);
                if (!str.Contains(chArray.GetValue(index).ToString())) str = str + chArray.GetValue(index);
                else i--;
            }
            return str;
        }


    }
}
