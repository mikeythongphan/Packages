using OneWitsCore.DataObjects;
using OneWitsCore.UnitOfWork;


namespace OneWitsCore.Abstract.Repositories
{
    public interface IAccountVerificationRepository : IRepositoryBase<AccountVerification, long>
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="target"></param>
        /// <param name="targetTypeId"></param>
        AccountVerification Create(string target, byte targetTypeId);
    }
}
