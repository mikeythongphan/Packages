using OneWitsCore.DataObjects;
using OneWitsCore.UnitOfWork;


namespace OneWitsCore.Abstract.Repositories
{
    public interface IAccountRepository : IRepositoryBase<Account, long>
    {
    }
}
