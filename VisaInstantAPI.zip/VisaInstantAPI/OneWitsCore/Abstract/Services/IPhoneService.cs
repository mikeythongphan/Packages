﻿using OneWitsCore.DataObjects;

namespace OneWitsCore.Abstract.Services
{
    public interface IPhoneService : IServiceBase
    {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="phoneNumber"></param>
        /// <param name="from"></param>
        /// <param name="message"></param>
        void SendTo(string phoneNumber, Account from, string message);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="mailTo"></param>
        /// <returns></returns>
        void SendPhoneVerification(string mailTo);
    }
}
