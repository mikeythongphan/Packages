﻿namespace OneWitsCore.Abstract.Services
{
    public interface IEmailService : IServiceBase
    {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="mailTo"></param>
        /// <param name="code"></param>
        /// <param name="fromName"></param>
        void SendEmailVerification(string mailTo, string code, string fromName);
    }
}
