﻿namespace OneWitsCore.Abstract.Services
{
    public interface IServiceBase
    {
    }
}
