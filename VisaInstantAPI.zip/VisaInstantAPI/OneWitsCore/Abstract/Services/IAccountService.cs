﻿namespace OneWitsCore.Abstract.Services
{
    public interface IAccountService : IServiceBase
    {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="email"></param>
        void SendEmailVerification(string email);

    }
}
