﻿using Microsoft.EntityFrameworkCore;
using OneWitsCore.DataObjects;
using OneWitsCore.UnitOfWork;


namespace OneWitsCore.DbContexts
{
    public interface IDbContextBase : IUnitOfWork
    {
        DbSet<Account> Accounts { get; set; }
        DbSet<AccountVerification> AccountVerifications { get; set; }
    }
}
