﻿using OneWitsCore.Auth;
using OneWitsCore.DataObjects;

namespace OneWitsCore.DTOs
{
    public class AccountDto
    {
        public string Id { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }
        public bool EmailConfirmed { get; set; }
        public string PhoneNumber { get; set; }
        public bool PhoneNumberConfirmed { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string StateProvince { get; set; }
        public string PostalCode { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="account"></param>
        /// <param name="authUser"></param>
        /// <returns></returns>
        public static AccountDto FromEntity(Account account, AuthUser authUser) {
            return new AccountDto {
                Id = authUser.Id,
                Email = authUser.Email,
                EmailConfirmed = authUser.EmailConfirmed,
                PhoneNumber = authUser.PhoneNumber,
                PhoneNumberConfirmed = authUser.PhoneNumberConfirmed,
                FirstName = account.FirstName,
                LastName = account.LastName,
                Address = account.Address,
                City = account.City,
                StateProvince = account.StateProvince,
                PostalCode = account.PostalCode,
            };
        }
    }
}
