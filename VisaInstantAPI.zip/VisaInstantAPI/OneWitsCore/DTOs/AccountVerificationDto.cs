﻿namespace OneWitsCore.DTOs
{
    public class AccountVerificationDto
    {
        public string? Email { get; set; }
        public string? PhoneNumber { get; set; }
        public string? VerificationCode { get; set; }

    }
}
