﻿namespace OneWitsCore.DTOs
{
    public class SaveFirebaseTokenDto
    {
        public long AccountId { get; set; }
        public string? Token { get; set; }
    }
}
