﻿using OneWitsCore.Auth.DTOs;
using OneWitsCore.Abstract.Services;

namespace OneWitsCore.Auth.Abstract
{
    public interface IAuthService : IServiceBase
    {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="phoneNumber"></param>
        /// <returns></returns>
        AuthResponseDto RequestToken(string phoneNumber);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        AuthResponseDto RequestVerifyPhone(AuthRequestDto dto);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        AuthResponseDto Login(AuthRequestDto dto);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        AuthResponseDto Register(AuthRequestDto dto);

    }

}
