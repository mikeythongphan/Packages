﻿using Microsoft.AspNetCore.Mvc;
using OneWitsCore.Auth.Abstract;
using OneWitsCore.Auth.DTOs;

namespace OneWitsCore.Auth
{

    /// <summary>
    /// 
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _authService;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="authService"></param>
        public AuthController(IAuthService authService)
        {
            _authService = authService;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("RequestToken")]
        public IActionResult RequestToken(AuthRequestDto dto)
        {
            var response = _authService.RequestToken(dto.PhoneNumber);
            return Ok(response);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("RequestVerifyPhone")]
        public IActionResult RequestVerifyPhone(AuthRequestDto dto)
        {
            var response = _authService.RequestVerifyPhone(dto);
            return Ok(response);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("login")]
        public IActionResult Login(AuthRequestDto dto)
        {
            var response = _authService.Login(dto);
            return Ok(response);
        }
        
        /// <summary>
        /// 
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost("register")]
        public IActionResult Register(AuthRequestDto dto)
        {
            var response = _authService.Register(dto);
            return Ok(response);
        }

    }
}
