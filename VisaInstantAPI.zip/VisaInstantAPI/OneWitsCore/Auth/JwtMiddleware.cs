using Microsoft.AspNetCore.Http;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Options;
using OneWitsCore.Settings;

namespace OneWitsCore.Auth
{

    /// <summary>
    /// 
    /// </summary>
    public class JwtMiddleware
    {

        private readonly JWTSettings _jwtSettings;
        private readonly RequestDelegate _next;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="jwtSettings"></param>
        /// <param name="next"></param>
        public JwtMiddleware(IOptions<JWTSettings> jwtSettings,
            RequestDelegate next)
        {
            _jwtSettings = jwtSettings.Value;
            _next = next;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        /// <param name="userManager"></param>
        /// <returns></returns>
        public async Task Invoke(HttpContext context, UserManager<AuthUser> userManager)
        {
            var token = context.Request.Headers["Authorization"].FirstOrDefault()?.Split(" ").Last();

            if (token != null) await AttachUserToContext(context, userManager, token);

            await _next(context);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        /// <param name="userManager"></param>
        /// <param name="token"></param>
        private async Task AttachUserToContext(HttpContext context, UserManager<AuthUser> userManager, string token)
        {

            try
            {
                var tokenHandler = new JwtSecurityTokenHandler();
                tokenHandler.ValidateToken(token, new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtSettings.Secret)),
                    ValidAudience = _jwtSettings.ValidAudience,
                    ValidIssuer = _jwtSettings.ValidIssuer,
                    ClockSkew = TimeSpan.Zero // set clockskew to zero so tokens expire exactly at token expiration time (instead of 5 minutes later)
                }, out SecurityToken validatedToken);

                var jwtToken = (JwtSecurityToken)validatedToken;
                var userId = jwtToken.Claims.First(x => x.Type == "id").Value;
                var accountId = jwtToken.Claims.First(x => x.Type == "aid").Value;

                context.Items["User"] = await userManager.FindByIdAsync(userId);
                context.Items["AccountId"] = accountId;
            }
            catch (Exception e)
            {
                // Ignore
            }

        }
    }
}