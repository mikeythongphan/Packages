using Microsoft.AspNetCore.Identity;
using Microsoft.IdentityModel.Tokens;
using OneWitsCore.Abstract.Services;
using OneWitsCore.Auth.Abstract;
using OneWitsCore.Auth.DTOs;
using OneWitsCore.DataObjects;
using OneWitsCore.Extensions;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.Extensions.Options;
using OneWitsCore.Abstract.Repositories;
using OneWitsCore.Settings;

namespace OneWitsCore.Auth
{
    public class AuthService : IAuthService
    {

        private readonly EnvSettings _envSettings;
        private readonly JWTSettings _jwtSettings;
        private readonly UserManager<AuthUser> _userManager;
        private readonly SignInManager<AuthUser> _signInManager;
        private readonly IAccountService _accountService;
        private readonly IPhoneService _phoneService;
        private readonly IAccountRepository _accountRepository;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="envSettings"></param>
        /// <param name="jwtSettings"></param>
        /// <param name="signInManager"></param>
        /// <param name="userManager"></param>
        /// <param name="accountService"></param>
        /// <param name="phoneService"></param>
        /// <param name="accountRepository"></param>
        public AuthService(IOptions<EnvSettings> envSettings,
            IOptions<JWTSettings> jwtSettings,
            SignInManager<AuthUser> signInManager,
            UserManager<AuthUser> userManager,
            IAccountService accountService,
            IPhoneService phoneService,
            IAccountRepository accountRepository)
        {
            _envSettings = envSettings.Value;
            _jwtSettings = jwtSettings.Value;
            _signInManager = signInManager;
            _userManager = userManager;
            _accountService = accountService;
            _phoneService = phoneService;
            _accountRepository = accountRepository;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="phoneNumber"></param>
        /// <returns></returns>
        public AuthResponseDto RequestToken(string phoneNumber)
        {

            var username = phoneNumber + _envSettings.Domain;
            var user = _userManager.FindByNameAsync(username).Result;
            var account = _accountRepository.First(x => x.AspNetUserId == user.Id);

            var token = GenerateJwtToken(user, account);

            return new AuthResponseDto
            {
                Token = token,
                Succeeded = true
            };
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public AuthResponseDto RequestVerifyPhone(AuthRequestDto dto)
        {

            Account account = null;
            var phoneNumber = dto.PhoneNumber;
            var username = phoneNumber + $"@{_envSettings.Domain}";

            var authUser = _userManager.FindByNameAsync(username).Result;
            if (authUser == null)
            {

                authUser = new AuthUser
                {
                    UserName = username,
                    Email = username,
                    EmailConfirmed = false,
                    PhoneNumber = phoneNumber,
                    PhoneNumberConfirmed = false
                };
                var pwd = Guid.NewGuid().ToString();
                var result = _userManager.CreateAsync(authUser, pwd).Result;
                if (!result.Succeeded) return AuthResponseDto.Fail(result.Errors.ToDeepMessages());

                account = _accountRepository.FirstOrDefault(x => x.PhoneNumber == phoneNumber);
                if (account == null)
                {
                    account = new Account
                    {
                        AspNetUserId = authUser.Id,
                        PhoneNumber = phoneNumber
                    };
                    _accountRepository.Insert(account);

                }
                else
                {
                    account.AspNetUserId = authUser.Id;
                    _accountRepository.Update(account);
                }
                
                _accountRepository.UOW.Commit();

            }
            else
            {
                authUser.PhoneNumberConfirmed = false;
                _userManager.UpdateAsync(authUser).Wait();
            }

            _phoneService.SendPhoneVerification(phoneNumber);

            account ??= _accountRepository.First(x => x.AspNetUserId == authUser.Id);
            var userModel = authUser.MapTo<AuthUser, AuthUserModel>();
            userModel.AccountId = account.Id;
            var token = GenerateJwtToken(authUser, account);

            return new AuthResponseDto
            {
                Token = token,
                User = userModel,
                Succeeded = true
            };

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public AuthResponseDto Login(AuthRequestDto dto)
        {
            
            var result = _signInManager.PasswordSignInAsync(dto.Email, dto.Password, true, lockoutOnFailure: false).Result;
            if (!result.Succeeded)
            {
                return new AuthResponseDto
                {
                    Succeeded = false,
                    Error = "Invalid username or password"
                };
            }

            var user = _userManager.FindByNameAsync(dto.Email).Result;
            var account = _accountRepository.First(x => x.AspNetUserId == user.Id);
            var token = GenerateJwtToken(user, account);

            return new AuthResponseDto
            {
                Token = token,
                User = user.MapTo<AuthUser, AuthUserModel>(),
                Succeeded = true
            };

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        public AuthResponseDto Register(AuthRequestDto dto)
        {

            var user = _userManager.FindByNameAsync(dto.Email).Result;
            if (user != null) return AuthResponseDto.Fail("This email address is not available.");

            var authUser = new AuthUser { UserName = dto.Email, Email = dto.Email, EmailConfirmed = true };
            var result = _userManager.CreateAsync(authUser, dto.Password).Result;
            if (!result.Succeeded) return AuthResponseDto.Fail(result.Errors.ToDeepMessages());

            _accountRepository.Insert(new Account { AspNetUserId = authUser.Id });
            _accountRepository.UOW.Commit();
            _accountService.SendEmailVerification(dto.Email);

            return AuthResponseDto.Succeed();

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="user"></param>
        /// <param name="account"></param>
        /// <returns></returns>
        private string GenerateJwtToken(AuthUser user, Account account)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_jwtSettings.Secret);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                {
                    new Claim("id", user.Id),
                    new Claim("aid", account.Id.ToString())
                }),
                Expires = DateTime.UtcNow.AddDays(7),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature),
                Audience = _jwtSettings.ValidAudience,
                Issuer = _jwtSettings.ValidIssuer
            };
            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }
    }
}