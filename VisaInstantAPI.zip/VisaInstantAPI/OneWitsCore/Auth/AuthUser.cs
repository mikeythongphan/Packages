using Microsoft.AspNetCore.Identity;

namespace OneWitsCore.Auth
{
    public class AuthUser : IdentityUser
    {
    }
}