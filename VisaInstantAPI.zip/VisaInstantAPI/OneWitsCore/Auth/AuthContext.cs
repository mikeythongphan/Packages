﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace OneWitsCore.Auth
{

    /// <summary>
    /// 
    /// </summary>
    public class AuthContext : IdentityDbContext<AuthUser>
    {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="options"></param>
        public AuthContext(DbContextOptions<AuthContext> options)
            : base(options)
        {
        }
    }
}
