namespace OneWitsCore.Auth.DTOs
{
    public class AuthResponseDto
    {

        public AuthUserModel User { get; set; }
        public string Token { get; set; }
        public bool Succeeded { get; set; }
        public string Error { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static AuthResponseDto Succeed() => new() { Succeeded = true };

        /// <summary>
        /// 
        /// </summary>
        /// <param name="error"></param>
        /// <returns></returns>
        public static AuthResponseDto Fail(string error) => new() { Succeeded = false, Error = error };

    }
}