namespace OneWitsCore.Auth.DTOs
{
    public class AuthRequestDto
    {

        public string? Email { get; set; }
        public string? Password { get; set; }
        public string? PhoneNumber { get; set; }

    }
}