﻿namespace OneWitsCore
{
    public static class CoreVars
    {

        public static string AppName { get; set; }

    }
}
