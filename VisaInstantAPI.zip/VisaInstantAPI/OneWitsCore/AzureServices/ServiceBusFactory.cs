﻿using Azure.Messaging.ServiceBus;

namespace OneWitsCore.AzureServices
{

    /// <summary>
    /// 
    /// </summary>
    public class ServiceBusFactory : IAsyncDisposable
    {

        private readonly ServiceBusClient _client;
        private List<Tuple<string, ServiceBusProcessor>> _processors;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="connStr"></param>
        public ServiceBusFactory(string connStr)
        {
            _client = new ServiceBusClient(connStr);
            _processors = new List<Tuple<string, ServiceBusProcessor>>();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="topic"></param>
        /// <param name="subs"></param>
        /// <returns></returns>
        public ServiceBusProcessor CreateSubs(string topic, string subs)
        {
            var processor = _client.CreateProcessor(topic, subs, new ServiceBusProcessorOptions());
            _processors.Add(new Tuple<string, ServiceBusProcessor>(subs, processor));
            return processor;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public async ValueTask DisposeAsync()
        {
            _processors.ForEach(async x => 
            {
                await x.Item2.StopProcessingAsync();
                await x.Item2.DisposeAsync();
            });
            await _client.DisposeAsync();
        }
    }
}
