﻿using Microsoft.Extensions.Options;
using OneWitsCore.Settings;
using System.Net;
using System.Net.Mail;
using OneWitsCore.Abstract.Services;

namespace OneWitsCore.Services
{
    public class EmailService : IEmailService
    {

        private readonly SMTPSettings _smtpSettings;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="smtpSettings"></param>
        public EmailService(IOptions<SMTPSettings> smtpSettings)
        {
            _smtpSettings = smtpSettings.Value;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="mailTo"></param>
        /// <param name="code"></param>
        /// <param name="fromName"></param>
        public void SendEmailVerification(string mailTo, string code, string fromName)
        {

            var subject = $"Email verification form {fromName}";
            var body = $"Thanks for signing up!<br/>" +
                       $"You're almost ready to get started.<br/>" +
                       $"Please use this verification code to verify your email address: {code}.";

            Send(mailTo, subject, body);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="mailTo"></param>
        /// <param name="subject"></param>
        /// <param name="body"></param>
        protected void Send(string mailTo, string subject, string body)
        {

            var mail = new MailMessage();
            mail.From = new MailAddress(_smtpSettings.Address, _smtpSettings.Name);
            mail.To.Add(mailTo);
            mail.Subject = subject;
            mail.Body = body;
            mail.IsBodyHtml = true;

            var smtp = new SmtpClient(_smtpSettings.Server);
            smtp.Port = _smtpSettings.Port;
            var credentials = new NetworkCredential(_smtpSettings.Address, _smtpSettings.Pwd);
            smtp.Credentials = credentials;

            smtp.SendAsync(mail, null);

        }
    }
}
