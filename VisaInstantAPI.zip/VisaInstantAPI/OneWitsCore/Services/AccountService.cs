﻿using Microsoft.Extensions.Logging;
using OneWitsCore.Abstract.Repositories;
using OneWitsCore.Abstract.Services;
using OneWitsCore.Constants;

namespace OneWitsCore.Services
{
    public class AccountService : IAccountService
    {

        private readonly ILogger<AccountService> _logger;
        private readonly IEmailService _emailService;
        private readonly IAccountVerificationRepository _accountVerificationRepository;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="emailService"></param>
        /// <param name="accountVerificationRepository"></param>
        public AccountService(ILogger<AccountService> logger,
            IEmailService emailService,
            IAccountVerificationRepository accountVerificationRepository)
        {
            _logger = logger;
            _emailService = emailService;
            _accountVerificationRepository = accountVerificationRepository;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="email"></param>
        /// <returns></returns>
        public void SendEmailVerification(string email)
        {
            var accountVerification = _accountVerificationRepository.Create(email, VerificationType.Email);
            _emailService.SendEmailVerification(email, accountVerification.VerificationCode, "Rao2Go");
        }

    }
}
