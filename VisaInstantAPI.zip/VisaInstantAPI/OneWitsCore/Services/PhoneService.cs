﻿using Microsoft.Extensions.Options;
using OneWitsCore.Settings;
using System.Net;
using System.Net.Mail;
using OneWitsCore.Abstract.Repositories;
using OneWitsCore.Abstract.Services;
using OneWitsCore.Constants;
using OneWitsCore.DataObjects;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;

namespace OneWitsCore.Services
{
    public class PhoneService : IPhoneService
    {

        private readonly SMTPSettings _smtpSettings;
        private readonly TwilioSettings _twilioSettings;
        private readonly IAccountVerificationRepository _accountVerificationRepository;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="smtpSettings"></param>
        /// <param name="twilioSettings"></param>
        /// <param name="accountVerificationRepository"></param>
        public PhoneService(IOptions<SMTPSettings> smtpSettings,
            IOptions<TwilioSettings> twilioSettings,
            IAccountVerificationRepository accountVerificationRepository)
        {
            _smtpSettings = smtpSettings.Value;
            _twilioSettings = twilioSettings.Value;
            _accountVerificationRepository = accountVerificationRepository;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="phoneNumber"></param>
        /// <param name="from"></param>
        /// <param name="message"></param>
        public void SendTo(string phoneNumber, Account from, string message)
        {

            var subject = $"From {from.FirstName} {from.LastName}";
            var body = $"{message}";

            Send(phoneNumber, subject, body);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="phoneNo"></param>
        /// <returns></returns>
        public void SendPhoneVerification(string phoneNo)
        {

            var accountVerification = _accountVerificationRepository.Create(phoneNo, VerificationType.Phone);
            var subject = "Phone verification from Rao2Go";
            var body = $"{accountVerification.VerificationCode} is your Rao2Go verification code";

            SendByTwilio(phoneNo, subject, body);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="phoneNo"></param>
        /// <param name="subject"></param>
        /// <param name="body"></param>
        protected void SendByTwilio(string phoneNo, string subject, string body)
        {
            TwilioClient.Init(_twilioSettings.AccountSid, _twilioSettings.Token);
            MessageResource.Create(from: new PhoneNumber(_twilioSettings.FromPhoneNumber), to: new PhoneNumber($"+1{phoneNo}"), body: body);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="phoneNo"></param>
        /// <param name="subject"></param>
        /// <param name="body"></param>
        protected void Send(string phoneNo, string subject, string body)
        {

            var mail = new MailMessage();
            mail.From = new MailAddress(_smtpSettings.Address, _smtpSettings.Name);
            mail.To.Add($"{phoneNo}@tmomail.net");
            mail.Subject = subject;
            mail.Body = body;
            mail.IsBodyHtml = false;

            var smtp = new SmtpClient(_smtpSettings.Server);
            smtp.Port = _smtpSettings.Port;
            var credentials = new NetworkCredential(_smtpSettings.Address, _smtpSettings.Pwd);
            smtp.Credentials = credentials;

            smtp.SendAsync(mail, null);

        }
    }
}
