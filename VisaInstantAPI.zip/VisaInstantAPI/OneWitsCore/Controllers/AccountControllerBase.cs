﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using OneWitsCore.Abstract.Repositories;
using OneWitsCore.Auth;
using OneWitsCore.DataObjects;
using OneWitsCore.DTOs;
using OneWitsCore.Settings;

namespace OneWitsCore.Controllers
{

    public abstract class AccountControllerBase : ControllerTableBase<Account, long>
    {

        protected readonly EnvSettings EnvSettings;
        protected readonly UserManager<AuthUser> UserManager;
        protected readonly IAccountVerificationRepository AccountVerificationRepository;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="envSettings"></param>
        /// <param name="userManager"></param>
        /// <param name="accountRepository"></param>
        /// <param name="accountVerificationRepository"></param>
        protected AccountControllerBase(IOptions<EnvSettings> envSettings,
            UserManager<AuthUser> userManager,
            IAccountRepository accountRepository,
            IAccountVerificationRepository accountVerificationRepository)
            : base(accountRepository)
        {
            EnvSettings = envSettings.Value;
            UserManager = userManager;
            AccountVerificationRepository = accountVerificationRepository;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("VerifyPhone")]
        public IActionResult VerifyPhone([FromBody] AccountVerificationDto dto)
        {

            var accountVerification = AccountVerificationRepository.FirstOrDefault(x =>
                x.Target == dto.PhoneNumber && x.VerificationCode == dto.VerificationCode);
            if (accountVerification == null) return Ok(new { Succeeded = false, Error = "Invalid verification code" });

            var email = $"{dto.PhoneNumber}@{EnvSettings.Domain}";
            var user = UserManager.FindByNameAsync(email).Result;
            user.PhoneNumberConfirmed = true;
            UserManager.UpdateAsync(user).Wait();
            AccountVerificationRepository.HardDelete(accountVerification);
            AccountVerificationRepository.UOW.Commit();
            return Ok(ResponseDto.Succeed());
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("VerifyEmail")]
        public IActionResult VerifyEmail([FromBody] AccountVerificationDto dto)
        {
            var accountVerification = AccountVerificationRepository.FirstOrDefault(x =>
                x.Target == dto.Email && x.VerificationCode == dto.VerificationCode);
            if (accountVerification == null) return Ok(new {Succeeded = false, Error = "Invalid verification code"});
            var user = UserManager.FindByNameAsync(dto.Email).Result;
            user.EmailConfirmed = true;
            UserManager.UpdateAsync(user).Wait();
            AccountVerificationRepository.HardDelete(accountVerification);
            AccountVerificationRepository.UOW.Commit();
            return Ok(ResponseDto.Succeed());
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("GetProfile")]
        public IActionResult GetProfile([FromQuery] string userId)
        {
            var account = Repos.First(x => x.AspNetUserId == userId);
            var user = UserManager.FindByIdAsync(userId).Result;
            if (account == null || user == null) return BadRequest(new { message = "Not found" });
            return Ok(ResponseDto.Succeed(AccountDto.FromEntity(account, user)));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dto"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("UpdateProfile")]
        public IActionResult UpdateProfile([FromBody] AccountDto dto)
        {

            var user = UserManager.FindByIdAsync(dto.Id).Result;
            user.Email = dto.Email;
            UserManager.UpdateAsync(user).Wait();

            var account = Repos.First(x => x.AspNetUserId == dto.Id);
            account.FirstName = dto.FirstName;
            account.LastName = dto.LastName;
            account.Address = dto.Address;
            account.City = dto.City;
            account.StateProvince = dto.StateProvince;
            account.PostalCode = dto.PostalCode;
            base.Update(account);

            return Ok(ResponseDto.Succeed(dto));

        }

    }
}
