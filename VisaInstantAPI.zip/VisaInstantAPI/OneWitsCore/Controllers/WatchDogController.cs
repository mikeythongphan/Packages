﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using OneWitsCore.DTOs;
using OneWitsCore.Settings;

namespace OneWitsCore.Controllers
{

    /// <summary>
    /// 
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class WatchDogController : ControllerBase
    {

        private readonly ConnStrSettings _connStrSettings;

        /// <summary>
        /// 
        /// </summary>
        public WatchDogController(IOptions<ConnStrSettings> connStrSettings)
        {
            _connStrSettings = connStrSettings.Value;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public IActionResult Get()
        {

            var appName = CoreVars.AppName.ToLower();
            var connStr = _connStrSettings.ConnectionString.ToLower();

            var db = string.Empty;
            if (connStr.Contains($"{appName}local;")) db = "LOCAL";
            else if (connStr.Contains($"{appName}dev;")) db = "DEV";
            else if (connStr.Contains($"{appName}qa;")) db = "QA";
            else if (connStr.Contains($"{appName}staging;")) db = "STAGING";
            else if (connStr.Contains($"{appName};")) db = "PROD";

            var result = new
            {
                Database = db
            };

            return Ok(ResponseDto.Succeed(result));
        }
    }
}
