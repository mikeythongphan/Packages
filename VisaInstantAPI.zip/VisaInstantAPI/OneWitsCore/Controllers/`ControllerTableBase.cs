﻿using Microsoft.AspNetCore.Mvc;
using OneWitsCore.DataObjects;
using System.Security.Claims;
using OneWitsCore.DTOs;
using OneWitsCore.UnitOfWork;


namespace OneWitsCore.Controllers
{

    /// <summary>
    /// 
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <typeparam name="TPK"></typeparam>
    public abstract class ControllerTableBase<T, TPK> : MvcControllerBase
        where T : DataObjectBase<TPK>
    {
        protected readonly IRepositoryBase<T, TPK> Repos;
        protected string? CurrentUserId => User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="repos"></param>
        protected ControllerTableBase(IRepositoryBase<T, TPK> repos)
        {
            Repos = repos;

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("Insert")]
        public virtual IActionResult Insert([FromBody] T obj)
        {
            Repos.Insert(obj);
            Repos.UOW.Commit();
            return Ok(ResponseDto.Succeed(obj));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("Update")]
        public virtual IActionResult Update([FromBody] T obj)
        {
            Repos.Update(obj);
            Repos.UOW.Commit();
            return Ok(ResponseDto.Succeed(obj));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("Delete")]
        public virtual IActionResult Delete([FromBody] TPK id)
        {
            Repos.Delete(id);
            Repos.UOW.Commit();
            return Ok(ResponseDto.Succeed(id));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("Get")]
        public virtual IActionResult Get([FromQuery] TPK id)
        {
            var obj = Repos.Get(id);
            return Ok(ResponseDto.Succeed(obj));
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("GetAll")]
        public virtual IActionResult GetAll()
        {
            var result = Repos.GetAll();
            return Ok(ResponseDto.Succeed(result));
        }

    }
}
