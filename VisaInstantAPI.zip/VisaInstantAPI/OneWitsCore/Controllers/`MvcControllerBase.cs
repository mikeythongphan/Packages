﻿using Microsoft.AspNetCore.Mvc;
using OneWitsCore.Extensions;

namespace OneWitsCore.Controllers
{
    public class MvcControllerBase : ControllerBase
    {
        public long AccountId => this.GetAccountId();
    }
}
