﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace OneWitsCore.DataObjects
{

    [Table("Account")]
    public class Account : DataObjectBase<long>
    {

        [MaxLength(450)]
        public string? AspNetUserId { get; set; }

        [MaxLength(100)]
        public string? FirstName { get; set; }

        [MaxLength(100)]
        public string? LastName { get; set; }

        [MaxLength(100)]
        public string? Address { get; set; }

        [MaxLength(100)]
        public string? City { get; set; }

        [MaxLength(2)]
        public string? StateProvince { get; set; }

        [MaxLength(10)]
        public string? PostalCode { get; set; }
        
        [MaxLength(20)]
        public string? PhoneNumber { get; set; }

        [MaxLength(256)]
        public string? Email { get; set; }

        [MaxLength(1000)]
        public string? FirebaseChatToken { get; set; }

    }
}
