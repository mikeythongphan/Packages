﻿namespace OneWitsCore.DataObjects
{
    public class DataObjectBase<TPK>
    {
        public TPK Id { get; set; }
        public bool Deleted { get; set; } = false;
    }
}
