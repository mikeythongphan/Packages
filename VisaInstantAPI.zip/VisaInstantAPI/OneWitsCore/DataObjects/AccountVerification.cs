﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace OneWitsCore.DataObjects
{

    [Table("AccountVerification")]
    public class AccountVerification : DataObjectBase<long>
    {

        [Required]
        [MaxLength(6)]
        public string VerificationCode { get; set; }

        public byte TargetTypeId { get; set; }

        [Required]
        [MaxLength(100)]
        public string Target { get; set; }

        public DateTime? ExpiredAt { get; set; }


    }
}
