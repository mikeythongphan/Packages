﻿using OneWitsCore.Abstract.Repositories;
using OneWitsCore.DataObjects;
using OneWitsCore.UnitOfWork;

namespace OneWitsCore.Repositories
{
    public class AccountRepository : RepositoryBase<Account, long>, IAccountRepository
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        public AccountRepository(IUnitOfWork context) : base(context)
        {
        }


    }
}
