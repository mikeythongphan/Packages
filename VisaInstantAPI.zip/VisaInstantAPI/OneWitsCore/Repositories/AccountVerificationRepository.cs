﻿using OneWitsCore.Abstract.Repositories;
using OneWitsCore.DataObjects;
using OneWitsCore.Helpers;
using OneWitsCore.UnitOfWork;


namespace OneWitsCore.Repositories
{

    /// <summary>
    /// 
    /// </summary>
    public class AccountVerificationRepository : RepositoryBase<AccountVerification, long>, IAccountVerificationRepository
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        public AccountVerificationRepository(IUnitOfWork context) : base(context)
        {
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="target"></param>
        /// <param name="targetTypeId"></param>
        public AccountVerification Create(string target, byte targetTypeId)
        {

            var targets = GetFiltered(x => x.Target == target).ToList();
            if (targets.Count > 0)
            {
                targets.ForEach(HardDelete);
                UOW.Commit();
            }

            var code = GenericHelper.GenerateVerificationCode(6);
            var accountVerification = new AccountVerification
            {
                VerificationCode = code,
                TargetTypeId = targetTypeId,
                Target = target
            };
            Insert(accountVerification);
            UOW.Commit();
            return accountVerification;
        }

    }
}
