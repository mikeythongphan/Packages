﻿using Microsoft.AspNetCore.Mvc;

namespace OneWitsCore.Extensions
{
    public static class MvcExtensions
    {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="controller"></param>
        /// <returns></returns>
        public static long GetAccountId(this ControllerBase controller)
        {

            var accountId = controller.HttpContext.Items["AccountId"]?.ToString();
            if (accountId == null) throw new Exception("MvcExtensions::GetAccountId::AccountId is NULL");
            return long.Parse(accountId);

        }

    }
}
