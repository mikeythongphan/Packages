﻿using Microsoft.AspNetCore.Identity;

namespace OneWitsCore.Extensions
{
    public static class ExceptionExtensions
    {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="errs"></param>
        /// <returns></returns>
        public static string ToDeepMessages(this IEnumerable<IdentityError> errs)
        {

            var errors = errs.ToList();
            if (!errors.Any()) return string.Empty;

            var message = errors.First().Description;
            var count = 1;
            while (count < errors.Count)
            {
                message += $"\n{errors[count].Description}";
            }

            return message;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="ex"></param>
        /// <returns></returns>
        public static string ToDeepMessages(this Exception ex)
        {
            if (ex == null) return string.Empty;
            var message = ex.Message;
            var count = 1;
            while (ex.InnerException != null)
            {
                ex = ex.InnerException;
                message += $"\n----------------------------------------";
                message += $"\nINNER EXCEPTION LEVEL {count++}";
                message += $"\n{ex.Message}";
            }

            return message;
        }

    }
}
