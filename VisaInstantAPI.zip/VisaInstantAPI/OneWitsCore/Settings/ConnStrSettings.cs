﻿namespace OneWitsCore.Settings
{
    public class ConnStrSettings
    {
        public string ConnectionString { get; set; }
    }
}
