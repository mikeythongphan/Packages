﻿namespace OneWitsCore.Settings
{
    public class TwilioSettings
    {
        public string AccountSid { get; set; }
        public string Token { get; set; }
        public string FromPhoneNumber { get; set; }
    }
}
