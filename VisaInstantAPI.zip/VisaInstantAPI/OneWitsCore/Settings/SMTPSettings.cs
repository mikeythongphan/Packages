﻿namespace OneWitsCore.Settings
{
    public class SMTPSettings
    {
        public string Name { get; set; }
        public string Address { get; set; }
        public string Server { get; set; }
        public int Port { get; set; }
        public string Pwd { get; set; }
    }
}
