﻿namespace OneWitsCore.Settings
{
    public class EnvSettings
    {
        public string Name { get; set; }
        public string Domain { get; set; }
    }
}
