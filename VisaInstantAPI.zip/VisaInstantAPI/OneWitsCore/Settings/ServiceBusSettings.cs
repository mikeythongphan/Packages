﻿namespace OneWitsCore.Settings
{
    public class ServiceBusSettings
    {
        public string ConnectionString { get; set; }
        public string AccountVerificationTopic { get; set; }
        public string AccountVerificationSubs { get; set; }
    }
}
