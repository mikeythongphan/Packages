﻿namespace OneWitsCore.Constants
{
    public static class VerificationType
    {
        public static byte Email => 1;
        public static byte Phone => 2;

    }
}
