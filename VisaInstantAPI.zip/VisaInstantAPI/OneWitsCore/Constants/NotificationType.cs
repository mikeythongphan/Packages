﻿namespace OneWitsCore.Constants
{
    public static class NotificationType
    {
        public static byte Chat => 1;
    }
}
