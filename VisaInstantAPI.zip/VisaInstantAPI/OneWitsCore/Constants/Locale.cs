namespace OneWitsCore.Constants
{
    /// <summary>
    /// 
    /// </summary>
    public static class Locale
    {
        public static string VN = "vi";
        public static string ENUS = "en";
    }
}
