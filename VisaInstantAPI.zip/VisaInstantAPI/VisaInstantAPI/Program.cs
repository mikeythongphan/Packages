using System.Net;
using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using OneWitsCore;
using OneWitsCore.Abstract.Repositories;
using OneWitsCore.Abstract.Services;
using OneWitsCore.Auth;
using OneWitsCore.Auth.Abstract;
using OneWitsCore.DTOs;
using OneWitsCore.Repositories;
using OneWitsCore.UnitOfWork;
using OneWitsCore.Services;
using OneWitsCore.Settings;
using VisaInstantCore.Abstract.Repositories;
using VisaInstantCore.DbContexts;
using VisaInstantCore.Repositories;

var builder = WebApplication.CreateBuilder(args);
if (builder == null) throw new ArgumentNullException(nameof(builder));

var name = System.Reflection.Assembly.GetExecutingAssembly().GetName().Name;
if (name != null) CoreVars.AppName = name.Replace("API", string.Empty);

// Add services to the container.
RegisterIdentityAndDbContext(builder.Services, builder.Configuration);
RegisterAuthentication(builder.Services, builder.Configuration);
RegisterSettings(builder.Services, builder.Configuration);
RegisterSystemServices(builder.Services);
RegisterServicesAndRepositories(builder.Services);
RegisterSwagger(builder.Services);

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
//if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "FilePointAPI v1"));
}

app.UseHttpsRedirection();

app.UseCors(x => x
    .AllowAnyMethod()
    .AllowAnyHeader()
    .SetIsOriginAllowed(origin => true)
    .AllowCredentials());

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.UseExceptionHandler(
    options =>
    {
        options.Run(async context =>
        {
            context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
            context.Response.ContentType = "application/json";
            var exceptionObject = context.Features.Get<IExceptionHandlerFeature>();
            if (null != exceptionObject)
            {
                var dto = ResponseDto.Fail(exceptionObject.Error.Message);
                await context.Response.WriteAsync(JsonConvert.SerializeObject(dto)).ConfigureAwait(false);
            }
        });
    }
);

app.UseMiddleware<JwtMiddleware>();

app.UseEndpoints(endpoints =>
{
    endpoints.MapControllerRoute(name: "default", pattern: "{controller}/{action}/{id?}");
});
app.MapControllers();

app.Run();

/// <summary>
/// 
/// </summary>
/// <param name="services"></param>
void RegisterAuthentication(IServiceCollection services, ConfigurationManager configuration)
{
    services.AddAuthentication(options =>
    {
        options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
        options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
        options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
    }).AddJwtBearer(options =>
    {
        options.SaveToken = true;
        options.RequireHttpsMetadata = false;
        options.TokenValidationParameters = new TokenValidationParameters()
        {
            ValidateIssuerSigningKey = true,
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidAudience = configuration["JWT:ValidAudience"],
            ValidIssuer = configuration["JWT:ValidIssuer"],
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration["JWT:Secret"]))
        };
        options.Events = new JwtBearerEvents
        {
            OnMessageReceived = context =>
            {

                var token = context.Request.Query["access_token"];
                var path = context.HttpContext.Request.Path;

                if (string.IsNullOrEmpty(token) || !path.StartsWithSegments("/chathub")) return Task.CompletedTask;

                context.Token = token;
                return Task.CompletedTask;

            }
        };
    });

}

/// <summary>
/// 
/// </summary>
/// <param name="services"></param>
void RegisterSystemServices(IServiceCollection services)
{
    services.AddSignalR(o =>
    {
        o.EnableDetailedErrors = true;
    });
    services.AddCors();
    services.AddControllers();
}

/// <summary>
/// 
/// </summary>
/// <param name="services"></param>
void RegisterIdentityAndDbContext(IServiceCollection services, ConfigurationManager configuration)
{
    var connStr = configuration.GetConnectionString("ConnectionString");
    services.AddDbContext<AuthContext>(options => options.UseSqlServer(connStr));
    //services.AddDatabaseDeveloperPageExceptionFilter();
    services.AddIdentity<AuthUser, IdentityRole>(options =>
    {
        options.SignIn.RequireConfirmedEmail = false;
        options.Password.RequireDigit = false;
        options.Password.RequiredLength = 1;
        options.Password.RequireNonAlphanumeric = false;
        options.Password.RequireUppercase = false;
        options.Password.RequireLowercase = false;
    }).AddEntityFrameworkStores<AuthContext>()
        .AddDefaultTokenProviders();

    services.AddDbContext<IUnitOfWork, VisaInstantContext>(options => options.UseSqlServer(connStr));


}

/// <summary>
/// 
/// </summary>
/// <param name="services"></param>
void RegisterSettings(IServiceCollection services, ConfigurationManager configuration)
{
    services.Configure<EnvSettings>(configuration.GetSection("ENV"));
    services.Configure<ConnStrSettings>(configuration.GetSection("ConnectionStrings"));
    services.Configure<ServiceBusSettings>(configuration.GetSection("ServiceBus"));
    services.Configure<SMTPSettings>(configuration.GetSection("SMP"));
    services.Configure<JWTSettings>(configuration.GetSection("JWT"));
    services.Configure<TwilioSettings>(configuration.GetSection("Twilio"));
}

/// <summary>
/// 
/// </summary>
/// <param name="services"></param>
void RegisterServicesAndRepositories(IServiceCollection services)
{

    services.AddScoped<IAuthService, AuthService>();
    services.AddScoped<IAccountService, AccountService>();
    services.AddScoped<IEmailService, EmailService>();
    services.AddScoped<IPhoneService, PhoneService>();

    services.AddScoped<ISiteContentRepository, SiteContentRepository>();
    services.AddScoped<IAccountRepository, AccountRepository>();
    services.AddScoped<IAccountVerificationRepository, AccountVerificationRepository>();
    services.AddScoped<ICustomerRepository, CustomerRepository>();
    services.AddScoped<IFormTravelDocumentRepository, FormTravelDocumentRepository>();

}

/// <summary>
/// 
/// </summary>
/// <param name="services"></param>
void RegisterSwagger(IServiceCollection services)
{
    services.AddSwaggerGen(options =>
    {
        options.SwaggerDoc("v1", new OpenApiInfo { Title = "VisaInstantAPI", Version = "v1" });
        options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
        {
            Description = "Example: 'Bearer 12345abcdef'",
            Name = "Authorization",
            In = ParameterLocation.Header,
            Type = SecuritySchemeType.ApiKey,
            Scheme = "Bearer"
        });

        options.AddSecurityRequirement(new OpenApiSecurityRequirement()
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference
                            {
                                Type = ReferenceType.SecurityScheme,
                                Id = "Bearer"
                            },
                            Scheme = "oauth2",
                            Name = "Bearer",
                            In = ParameterLocation.Header,

                        },
                        new List<string>()
                    }
                });
    });

}
