﻿using Microsoft.AspNetCore.Mvc;
using OneWitsCore.Controllers;
using VisaInstantCore.Abstract.Repositories;
using VisaInstantCore.DataObjects;

namespace VisaInstantCore.Controllers
{

    /// <summary>
    /// 
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class CustomerController : ControllerTableBase<Customer, long>
    {

        /// <summary>
        /// 
        /// </summary>
        public CustomerController(ICustomerRepository repos)
            : base(repos)
        {
        }

    }
}
