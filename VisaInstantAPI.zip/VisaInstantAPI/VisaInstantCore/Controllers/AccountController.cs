﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using OneWitsCore.Abstract.Repositories;
using OneWitsCore.Auth;
using OneWitsCore.Controllers;
using OneWitsCore.UnitOfWork;
using OneWitsCore.Settings;

namespace VisaInstantCore.Controllers
{

    /// <summary>
    /// 
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class AccountController : AccountControllerBase
    {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="envSettings"></param>
        /// <param name="dbContext"></param>
        /// <param name="userManager"></param>
        /// <param name="accountRepository"></param>
        /// <param name="accountVerificationRepository"></param>
        public AccountController(IOptions<EnvSettings> envSettings,
            IUnitOfWork dbContext,
            UserManager<AuthUser> userManager,
            IAccountRepository accountRepository,
            IAccountVerificationRepository accountVerificationRepository)
            : base(envSettings, userManager, accountRepository, accountVerificationRepository)
        {
        }



    }
}
