﻿using Microsoft.AspNetCore.Mvc;
using OneWitsCore.Controllers;
using VisaInstantCore.Abstract.Repositories;
using VisaInstantCore.DataObjects;

namespace VisaInstantCore.Controllers
{

    /// <summary>
    /// 
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class SponsorController : ControllerTableBase<Sponsor, long>
    {

        /// <summary>
        /// 
        /// </summary>
        public SponsorController(ISponsorRepository repos)
            : base(repos)
        {
        }

    }
}
