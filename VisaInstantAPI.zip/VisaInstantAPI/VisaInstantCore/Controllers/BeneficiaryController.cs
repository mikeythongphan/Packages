﻿using Microsoft.AspNetCore.Mvc;
using OneWitsCore.Controllers;
using VisaInstantCore.Abstract.Repositories;
using VisaInstantCore.DataObjects;

namespace VisaInstantCore.Controllers
{

    /// <summary>
    /// 
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class BeneficiaryController : ControllerTableBase<Beneficiary, long>
    {

        /// <summary>
        /// 
        /// </summary>
        public BeneficiaryController(IBeneficiaryRepository repos)
            : base(repos)
        {
        }

    }
}
