﻿using Microsoft.AspNetCore.Mvc;
using VisaInstantCore.DataObjects;
using VisaInstantCore.Helpers;
using OneWitsCore.Controllers;
using VisaInstantCore.Abstract.Repositories;

namespace VisaInstantCore.Controllers
{

    /// <summary>
    /// 
    /// </summary>
    [ApiController]
    [Route("api/[controller]")]
    public class SiteContentController : ControllerTableBase<SiteContent, long>
    {

        /// <summary>
        /// 
        /// </summary>
        public SiteContentController(ISiteContentRepository repos)
            : base(repos)
        {
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="country"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("GetByCountry")]
        public IActionResult GetByCountry(string country, string pageName)
        {            
            try
            {
                var siteContent = Repos.GetAll();
                IQueryable<SiteContent> preQuery;
                if (pageName == "common")
                {
                    preQuery = from x in siteContent
                        where x.ContentTypeId == 1 && !x.Deleted
                        select x;
                }
                else
                {
                    preQuery = from x in siteContent
                        where x.ContentTypeId == 2 && x.PageName == pageName && !x.Deleted
                        select x;
                }
                var languages = preQuery.ToList();
                var result = LanguageHelper.BuildTreeMessages(languages, country);

                return Ok(new
                {
                    Data = result
                });
            }
            catch (Exception e)
            {
                throw;
            }
        }
    }
}
