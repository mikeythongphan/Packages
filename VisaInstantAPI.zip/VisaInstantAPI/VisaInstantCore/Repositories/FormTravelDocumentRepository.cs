
using OneWitsCore.UnitOfWork;
using VisaInstantCore.Abstract.Repositories;
using VisaInstantCore.DataObjects;

namespace VisaInstantCore.Repositories
{
    public class FormTravelDocumentRepository : RepositoryBase<FormTravelDocument, long>, IFormTravelDocumentRepository
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        public FormTravelDocumentRepository(IUnitOfWork context) : base(context)
        {
        }
    }
}
