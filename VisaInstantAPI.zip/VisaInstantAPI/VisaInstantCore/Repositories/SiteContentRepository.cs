
using OneWitsCore.UnitOfWork;
using VisaInstantCore.Abstract.Repositories;
using VisaInstantCore.DataObjects;

namespace VisaInstantCore.Repositories
{
    public class SiteContentRepository : RepositoryBase<SiteContent, long>, ISiteContentRepository
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        public SiteContentRepository(IUnitOfWork context) : base(context)
        {
        }
    }
}
