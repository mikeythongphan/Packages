
using OneWitsCore.UnitOfWork;
using VisaInstantCore.Abstract.Repositories;
using VisaInstantCore.DataObjects;

namespace VisaInstantCore.Repositories
{
    public class BeneficiaryRepository : RepositoryBase<Beneficiary, long>, IBeneficiaryRepository
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        public BeneficiaryRepository(IUnitOfWork context) : base(context)
        {
        }
    }
}
