
using OneWitsCore.UnitOfWork;
using VisaInstantCore.Abstract.Repositories;
using VisaInstantCore.DataObjects;

namespace VisaInstantCore.Repositories
{
    public class SponsorRepository : RepositoryBase<Sponsor, long>, ISponsorRepository
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        public SponsorRepository(IUnitOfWork context) : base(context)
        {
        }
    }
}
