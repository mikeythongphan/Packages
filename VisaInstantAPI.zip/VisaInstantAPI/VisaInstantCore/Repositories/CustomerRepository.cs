
using OneWitsCore.UnitOfWork;
using VisaInstantCore.Abstract.Repositories;
using VisaInstantCore.DataObjects;

namespace VisaInstantCore.Repositories
{
    public class CustomerRepository : RepositoryBase<Customer, long>, ICustomerRepository
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="context"></param>
        public CustomerRepository(IUnitOfWork context) : base(context)
        {
        }
    }
}
