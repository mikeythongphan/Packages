using OneWitsCore.Constants;
using VisaInstantCore.DataObjects;

namespace VisaInstantCore.Helpers
{
    public static class LanguageHelper
    {

        /// <summary>
        /// 
        /// </summary>
        /// <param name="languages"></param>
        /// <param name="locale"></param>
        /// <returns></returns>
        public static Dictionary<string, string> BuildTreeMessages(List<SiteContent> languages, string locale)
        {
            var result = new Dictionary<string, string>();
            foreach (var item in languages)
            {
                var message = Locale.VN == locale ? item.VN : item.ENUS;
                if(result.ContainsKey(item.FieldName)) {
                    result[item.FieldName] = message;
                } else {
                    result.Add(item.FieldName, message);
                }
            }
            return result;
        }

    }
}