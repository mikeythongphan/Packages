﻿using Microsoft.EntityFrameworkCore;
using OneWitsCore.DbContexts;
using VisaInstantCore.DataObjects;

namespace VisaInstantCore.DbContexts
{
    public class VisaInstantContext : DbContextBase, IVisaInstantContext
    {

        public virtual DbSet<Beneficiary> Beneficiaries { get; set; }
        public virtual DbSet<SiteContent> Languages { get; set; }
        public virtual DbSet<Sponsor> Sponsors { get; set; }
        public virtual DbSet<Customer> Customers { get; set; }
        public virtual DbSet<FormTravelDocument> FormTravelDocuments { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="settings"></param>
        public VisaInstantContext(DbContextOptions options)
            : base(options)
        {
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="modelBuilder"></param>
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }

    }
}
