﻿using Microsoft.EntityFrameworkCore;
using OneWitsCore.DbContexts;
using VisaInstantCore.DataObjects;

namespace VisaInstantCore.DbContexts
{
    public interface IVisaInstantContext : IDbContextBase
    {
        DbSet<SiteContent> Languages { get; set; }
        DbSet<FormTravelDocument> FormTravelDocuments { get; set; }
    }
}
