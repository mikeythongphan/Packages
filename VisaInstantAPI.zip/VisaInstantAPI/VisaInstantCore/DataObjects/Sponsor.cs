using OneWitsCore.DataObjects;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace VisaInstantCore.DataObjects
{
    [Table("Sponsor")]
    public partial class Sponsor : DataObjectBase<long>
    {

        [StringLength(1000)]
        public string SponsorFirstName { get; set; }

        [StringLength(1000)]
        public string SponsorMiddleName { get; set; }

        [StringLength(1000)]
        public string SponsorLastName { get; set; }

    }
}
