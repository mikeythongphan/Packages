﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using OneWitsCore.DataObjects;

namespace VisaInstantCore.DataObjects
{

    public partial class FormTravelDocument
    {
    }
}