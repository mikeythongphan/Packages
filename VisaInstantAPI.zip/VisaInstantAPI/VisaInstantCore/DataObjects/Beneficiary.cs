using OneWitsCore.DataObjects;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace VisaInstantCore.DataObjects
{

    [Table("Beneficiary")]
    public partial class Beneficiary : DataObjectBase<long>
    {

        [StringLength(1000)]
        public string FirstName { get; set; }

        [StringLength(1000)]
        public string MiddleName { get; set; }

        [StringLength(1000)]
        public string LastName { get; set; }

    }
}
