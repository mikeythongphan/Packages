using OneWitsCore.DataObjects;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace VisaInstantCore.DataObjects
{
    [Table("SiteContent")]
    public partial class SiteContent : DataObjectBase<long>
    {

        public short? ContentTypeId { get; set; }

        [MaxLength(100)]
        public string FieldName { get; set; }

        public string ENUS { get; set; }

        public string VN { get; set; }

        public string? PageName { get; set; }
    }
}
