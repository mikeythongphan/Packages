using OneWitsCore.UnitOfWork;
using VisaInstantCore.DataObjects;

namespace VisaInstantCore.Abstract.Repositories
{
    public interface ISponsorRepository : IRepositoryBase<Sponsor, long>
    {
    }
}
