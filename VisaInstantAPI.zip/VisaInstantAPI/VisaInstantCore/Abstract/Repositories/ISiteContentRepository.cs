using OneWitsCore.UnitOfWork;
using VisaInstantCore.DataObjects;

namespace VisaInstantCore.Abstract.Repositories
{
    public interface ISiteContentRepository : IRepositoryBase<SiteContent, long>
    {
    }
}
