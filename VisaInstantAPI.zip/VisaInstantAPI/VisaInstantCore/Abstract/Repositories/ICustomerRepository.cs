using OneWitsCore.UnitOfWork;
using VisaInstantCore.DataObjects;

namespace VisaInstantCore.Abstract.Repositories
{
    public interface ICustomerRepository : IRepositoryBase<Customer, long>
    {
    }
}
